# Özel Türkçe Java Klavye Uygulaması

Bu proje, Android platformu için Java diliyle geliştirilmiş, kapsamlı bir özel klavye uygulamasıdır. 
Kullanıcıların Türkçe karakterleri (ğ, ü, ş, i, ö, ç) kolayca kullanabilmesini sağlar ve bir kurulum sihirbazı içerir.

## Özellikler
- **Tamamen Java**: Modern Android standartlarına uygun Java kodu.
- **Türkçe Karakter Desteği**: QWERTY dizilimine entegre edilmiş Türkçe harfler.
- **Emoji Desteği**: Temel emoji girişi için ayrılmış özel tuş.
- **Kurulum Sihirbazı**: Uygulama içinden klavyeyi etkinleştirme ve seçme adımları.
- **İzin Yönetimi**: Depolama izinlerini kontrol eden ve isteyen yapı.
- **Shift Desteği**: Büyük/Küçük harf geçişi ve Türkçe karakter uyumluluğu.

## Gereksinimler
- Android Studio Flamingo veya daha yeni bir sürüm.
- Android SDK 21 (Lollipop) veya üzeri.
- Java JDK 11 veya 17.

## Kurulum ve Çalıştırma
1. Dosyaları projenize kopyalayın.
2. `AndroidManifest.xml` dosyasındaki paket isminin `com.ozel.klavye` olduğundan emin olun.
3. Uygulamayı bir Android cihazda veya emülatörde çalıştırın.
4. Ana ekrandaki adımları sırasıyla izleyin:
    - **Adım 1**: Depolama izni verin.
    - **Adım 2**: "Klavyeyi Ayarlardan Etkinleştir" butonuna basıp listeden "Gelişmiş Java Klavye"yi açın.
    - **Adım 3**: "Klavyeyi Varsayılan Seç" butonuna basıp klavyenizi aktif hale getirin.

## Proje Yapısı
- `MainActivity.java`: İzinler ve klavye kurulum mantığını yönetir.
- `KlavyeServisi.java`: Tuş vuruşlarını dinleyen ve metin alanına karakter gönderen ana servis.
- `qwerty.xml`: Klavyenin görsel tuş dizilimini ve karakter kodlarını tanımlar.
- `keyboard_view.xml`: Klavyenin UI bileşenini tanımlar.

## Notlar
- `KeyboardView` sınıfı Android tarafından 'deprecated' (eskimiş) olarak işaretlenmiş olsa da, özel klavye mantığını öğrenmek ve hızlı prototipleme için hala en stabil yöntemdir.
- Depolama izni, ileride klavyeye fotoğraf ekleme veya tema kaydetme gibi özellikler eklemek isterseniz hazır bir altyapı sunar.
